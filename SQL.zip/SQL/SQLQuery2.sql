SELECT COUNT(*) AS rows20092010 
from [dbo].[Year 2010-2011];

SELECT COUNT(*) AS rows20092010 
from [dbo].[Year 2009-2010];

select * from [dbo].[Year 2010-2011];

