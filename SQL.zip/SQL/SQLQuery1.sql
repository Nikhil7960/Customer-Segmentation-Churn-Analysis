CREATE DATABASE EcommerceCustomerAnalytics;
